package kotlinvalidation.models

import kotlinx.serialization.Serializable
import org.valiktor.functions.hasSize
import org.valiktor.functions.isNotBlank
import org.valiktor.functions.isPositive
import org.valiktor.validate

@Serializable
data class Transaction(
    val orderPartyAccount: String,
    val orderPartyCurrency: String,
    val chargesAccount: String,
    val chargesAccountCurrency: String,
    val accountCurrency: String,
    val transactionAmount: Float,
    val scheduledDate: String,
    val transactionCurrency: String,
    val counterPartyAccount: String,
    val counterAccountType: String,
    val counterBankName: String,
    val counterAccountCurrency: String,
    val productCode: String,
    val valueDate: String,
    val transactionMode: String,
)


fun validateTransaction(transaction: Transaction) {
    validate(transaction) {
        validate(Transaction::orderPartyAccount).isNotBlank().hasSize(1,35)
        validate(Transaction::orderPartyCurrency).isNotBlank().hasSize(min = 1, max = 3)
        validate(Transaction::chargesAccount).isNotBlank().hasSize(min = 1, max = 35)
        validate(Transaction::chargesAccountCurrency).isNotBlank().hasSize(min = 1, max = 3)
        validate(Transaction::accountCurrency).isNotBlank().hasSize(min = 1, max = 3)
        validate(Transaction::transactionAmount).isPositive().isPositive()
        validate(Transaction::scheduledDate).isNotBlank()
        validate(Transaction::transactionCurrency).isNotBlank().hasSize(min = 1, max = 3)
        validate(Transaction::counterPartyAccount).isNotBlank().hasSize(min = 1, max = 35)
        validate(Transaction::counterAccountType).isNotBlank().hasSize(min = 1, max = 2)
        validate(Transaction::counterBankName).isNotBlank().hasSize(min = 1, max = 35)
        validate(Transaction::counterAccountCurrency).isNotBlank().hasSize(min = 1, max = 3)
        validate(Transaction::productCode).isNotBlank().hasSize(min = 1, max = 3)
        validate(Transaction::valueDate).isNotBlank()
        validate(Transaction::transactionMode).isNotBlank().hasSize(min = 1, max = 3)
    }
}