package kotlinvalidation.plugins

import io.ktor.http.*
import io.ktor.server.routing.*
import io.ktor.server.response.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import kotlinvalidation.models.Transaction
import kotlinvalidation.models.validateTransaction
import kotlinx.serialization.Serializable
import org.valiktor.ConstraintViolationException
import org.valiktor.i18n.toMessage
import java.util.*

@Serializable
data class ErrorResponse(val errors: Map<String, String>)

fun Application.configureRouting() {
    routing {
        post("/payment/validate") {
            try {
                val transaction = call.receive<Transaction>()
                validateTransaction(transaction);

                call.respond(HttpStatusCode.OK, "Validation passed.")
            } catch (ex: ConstraintViolationException) {
                val errorMap = ex.constraintViolations
                    .associateBy({ it.property }, { it.toMessage(locale = Locale.ENGLISH).message })

                val errorResponse = ErrorResponse(errors = errorMap)
                call.respond(HttpStatusCode.BadRequest, errorResponse)
            }
        }
    }
}
